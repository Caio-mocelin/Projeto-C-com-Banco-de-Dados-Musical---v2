﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C__com_Banco_de_Dados_Musical
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=musica;password=root;";
            string query = "SELECT a.nome AS artista, al.titulo AS album, m.titulo AS musica, a.tipo\r\nFROM artistas a\r\nJOIN albuns al ON al.artista_id = a.id\r\nJOIN musicas m ON m.album_id = al.id;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch
                {
                    MessageBox.Show("erro");

                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 mus = new Form1();
            this.Hide();
            mus.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=musica;password=root;";
            string query = "SELECT m.titulo AS musica, al.titulo AS album, al.ano, ar.nome AS artista, ar.tipo\r\nFROM musicas m\r\nJOIN albuns al ON m.album_id = al.id\r\nJOIN artistas ar ON al.artista_id = ar.id\r\nWHERE al.ano < 2000 and ar.tipo = 1;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch
                {
                    MessageBox.Show("erro");

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;User Id=root;database=musica;password=root;";
            string query = "SELECT titulo, COUNT(album_id) AS qtd_albuns\r\nFROM musicas\r\nGROUP BY titulo\r\nHAVING COUNT(album_id) > 1;";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    MySqlDataAdapter da = new MySqlDataAdapter(query, connection);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch
                {
                    MessageBox.Show("erro");

                }
            }
        }
    }
}
