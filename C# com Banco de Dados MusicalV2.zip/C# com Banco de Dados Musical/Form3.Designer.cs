﻿namespace C__com_Banco_de_Dados_Musical
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.Location = new Point(695, 410);
            button2.Name = "button2";
            button2.Size = new Size(89, 35);
            button2.TabIndex = 5;
            button2.Text = "sair";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(4, 5);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(792, 308);
            dataGridView1.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(39, 319);
            button1.Name = "button1";
            button1.Size = new Size(198, 65);
            button1.TabIndex = 3;
            button1.Text = "ARTISTAS POR ORDEM DECRESCENTE";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.Location = new Point(297, 319);
            button3.Name = "button3";
            button3.Size = new Size(198, 89);
            button3.TabIndex = 6;
            button3.Text = "ARTISTAS QUE TÊM ÁLBUNS LANÇADOS ANTES DE 1990 E TAMBÉM DEPOIS DE 2010";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(564, 319);
            button4.Name = "button4";
            button4.Size = new Size(198, 51);
            button4.TabIndex = 7;
            button4.Text = "ARTISTAS DIFERENTES QUE GRAVARAM A MESMA MUSICA";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button button2;
        private DataGridView dataGridView1;
        private Button button1;
        private Button button3;
        private Button button4;
    }
}