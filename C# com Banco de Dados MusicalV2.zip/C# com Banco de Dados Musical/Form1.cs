namespace C__com_Banco_de_Dados_Musical
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Form2 mus = new Form2();
            this.Hide();
            mus.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form3 al = new Form3();
            this.Hide();
            al.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 men = new Form4();
            this.Hide();
            men.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
